export enum Role {
  isAdmin = 'admin',
  isUser = 'user',
}
